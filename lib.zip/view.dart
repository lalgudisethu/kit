import 'package:flutter/material.dart';

class ViewData extends StatelessWidget {
  const ViewData({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('View Data')),
      body: SingleChildScrollView(
        child: Center(
          child: Text('All Data Can be seen here'),
        ),
      ),
    );
  }
}