import 'package:flutter/material.dart';

class DelData extends StatelessWidget {
  const DelData({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Delete Dta')),
      body: Center(
        child: Text('Delete Data goes here'),

      ),
    );
  }
}