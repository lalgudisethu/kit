import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class MyAdd extends StatefulWidget {
  const MyAdd({super.key});

  @override
  State<MyAdd> createState() => _MyAddState();
}

class _MyAddState extends State<MyAdd> {
  TextEditingController nameCtrl = TextEditingController();
  TextEditingController degCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Data')),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              TextField(
                controller: nameCtrl,
                decoration: InputDecoration(
                  hintText: 'Enter Name'
                ),
              ),
              SizedBox(
                height: 10,
              ),
              TextField(
                controller: degCtrl,
                decoration: InputDecoration(
                  hintText: 'Enter Degree'
                ),
              ),
              SizedBox(
                height: 10,
              ),
              ElevatedButton(
                onPressed: (){}, child: Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}