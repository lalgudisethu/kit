import 'package:flutter/material.dart';

class UpdData extends StatefulWidget {
  const UpdData({super.key});

  @override
  State<UpdData> createState() => _UpdDataState();
}

class _UpdDataState extends State<UpdData> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Update Data')),
      body: Center(
        child: Text('Update Data Goes here'),
      ),
    );
  }
}