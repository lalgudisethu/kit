import 'package:flutter/material.dart';
import 'package:mywhatsapp/add.dart';
import 'package:mywhatsapp/upd.dart';

import 'del.dart';
import 'view.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {

  TabController? _tabController;
  // addition, deletion, display , and update data
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this); // initialized
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TabBar Data Processing '),
        actions: [
        IconButton(onPressed: (){}, icon: Icon(Icons.search)),
        IconButton(onPressed: (){}, icon: Icon(Icons.list)),
      ],
      bottom: TabBar(
        controller: _tabController,
        indicatorColor: Colors.red,
        tabs: [
        Tab(text: 'Add ',),
        Tab(text: 'Del',),
        Tab(text: 'Upd',),
        Tab(text: 'Disp',),
      ])
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          MyAdd(),
          DelData(),
          UpdData(),
          ViewData(),
        ])
    );
  }
}

